{
    'name': "Estate Account",
    'version': '1.0',
    'depends': ['account', 'estate'],
    'author': "Talha Butt",
    'sequence': 0,
    'category': 'Category',
    'description': """
  This is a test module for account module installation!
  """,

    # data files always loaded at installation

    'data': [],

    'installable': True,
    'auto_install': False,
    'application': True,

}
